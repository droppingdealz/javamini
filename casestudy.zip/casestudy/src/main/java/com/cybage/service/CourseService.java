package com.cybage.service;

import java.util.List;

import com.cybage.model.Courses;

public interface CourseService {
	public List<Courses> findCourse() throws Exception;

}

