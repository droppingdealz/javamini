package com.cybage.exception;

public class CourseException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CourseException(String msg) {
		super(msg);
	}
}
