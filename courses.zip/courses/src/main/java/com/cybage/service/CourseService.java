package com.cybage.service;

import java.util.List;

import com.cybage.model.Course;

public interface CourseService {

	public List<Course> findCourses() throws Exception;

	}

